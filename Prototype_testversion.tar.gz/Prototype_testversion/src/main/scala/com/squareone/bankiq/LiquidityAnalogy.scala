package com.squareone.bankiq

import org.apache.spark.sql.{Row, SparkSession}
import DirectMatching.sqlContext

object LiquidityAnalogy {

  def CashInfo = {
    val spark = sqlContext

    val data = spark.read.format("org.apache.spark.csv").option("header", "true").csv("DataFile/AR.csv")
    val df = data.selectExpr("cast (AR as Int) AR", "cast (AP as Int) AP", "Date")
    var balance = 400000.0

    def cash(row: Row) = {
      val p = row(1).toString.toDouble - row(2).toString.toDouble
      balance = balance + p
      (row(0).toString.toInt, balance)
    }

    def make(row:Row) = {
      Cash(row(0).toString,row(1).toString.toDouble)
    }
    import spark.implicits._
    df.groupBy("Date").sum("AR", "AP").map(cash(_)).toDF("Day", "Balance").orderBy("Day").toDF().collect().map(make(_))
  }
}
