package com.squareone.bankiq

import org.apache.spark.sql.{Row, SparkSession}

object DSO {
  def CustomerDso = {
    val sqlContext = SparkSession.builder().appName("DSO").master("local").getOrCreate()

    val dso = sqlContext.read.option("header","true").csv("DataFile/test-DSO.csv")

    dso.createOrReplaceTempView("dso_df")

    def customerDSO(row:Row)={
      CustomerDSO(row(0).toString,row(1).toString.toDouble.ceil)
    }

    val customer_dso = sqlContext.sql("SELECT customerID," + //,SUM(InvoiceAmount), SUM(DaysLate*InvoiceAmount), " +
      "SUM(DaysLate*InvoiceAmount)/Sum(InvoiceAmount)  FROM dso_df GROUP BY customerID order by 2 desc")

    customer_dso.toDF().collect().map(customerDSO(_))
  }

  def DisputedDso = {
    val sqlContext = SparkSession.builder().appName("DSO").master("local").getOrCreate()

    val dso = sqlContext.read.option("header","true").csv("DataFile/test-DSO.csv")

    dso.createOrReplaceTempView("dso_df")
  def make (a:String):String = a match {
    case a if a.toUpperCase == "YES" => "Disputed"
    case a if a.toUpperCase == "NO" => "Undisputed"
    case _ => "Undefined"
  }
    def DisputedDso(row:Row)={
      DisputedDSO(make(row(0).toString),row(1).toString.toDouble.ceil)
    }

    val disputed_dso = sqlContext.sql("SELECT Disputed, SUM(DaysLate*InvoiceAmount)/Sum(InvoiceAmount) AS Undisputed FROM dso_df GROUP BY Disputed")
    println("DisputedDso")
    disputed_dso.show()
    disputed_dso.toDF().collect().map(DisputedDso(_))
  }
  def predictDSO: Unit ={
    logistic
  }
}
