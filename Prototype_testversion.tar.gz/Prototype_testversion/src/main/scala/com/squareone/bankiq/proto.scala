package com.squareone.bankiq

import akka.actor.ActorSystem
import akka.http.scaladsl.Http
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport
import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.server.Route
import akka.stream.ActorMaterializer
import spray.json.DefaultJsonProtocol

import scala.io.StdIn
import scala.util.{Failure, Success}



trait JsonSupport extends SprayJsonSupport with DefaultJsonProtocol {
  implicit val matched = jsonFormat5(MatchedInvoice)
  implicit val Cdso= jsonFormat2(CustomerDSO)
  implicit val Ddso = jsonFormat2(DisputedDSO)
  implicit val Suspense = jsonFormat6(Transaction)
  implicit val Delayed = jsonFormat7(DelayedIndicator)
  implicit val Liquid = jsonFormat2(Cash)
  implicit val matched2 = jsonFormat8(MatchedInvoice2)
}

object proto extends App with JsonSupport {
  implicit val system = ActorSystem()
  implicit val mat = ActorMaterializer()


  import system.dispatcher
  def route: Route =

    path("match") {
      get {
        complete(MultipleInvoice.matchedMultiple)
      }
    }~
   path("Cdso") {
          get {
            complete(DSO.CustomerDso)
          }
      }~
    path("Ddso") {
      get {
        complete(DSO.DisputedDso)
      }
    }~
    path("Pmatch") {
      get {
        complete(ProbableMatch.probMatch)
      }
    }~
    path("Stran") {
      get {
        complete(SuspenseTransaction.susTran)
      }
    }~
    path("delay") {
      get {
        complete(predictionDso.finalResult)
      }}~
        path("cash") {
          get {
            complete(LiquidityAnalogy.CashInfo)
          }
    }
  //172.16.0.183
  Http().bindAndHandleAsync(Route.asyncHandler(route), "172.16.0.230",8080)//"172.16.0.230", 8080)
    .onComplete {
      case Success(_) => println("Server started on port 8080")
        StdIn.readLine()
        println("Going down")
        system.terminate()

      case Failure(e) => println("Binding error")
        e.printStackTrace()
        system.terminate()
    }
}
