package com.squareone.bankiq
import com.squareone.bankiq.InvoiceRecognition.makeJson

object ProbableMatch {
  val sqlcontext = DirectMatching.sqlContext
  val invoice = DirectMatching.invoice
  val payment = DirectMatching.payment
  val matchedInvoice = MultipleInvoice.multipleMatchedInvoice

  invoice.createOrReplaceTempView("invoice_df")
  payment.createOrReplaceTempView("payment_df")
  matchedInvoice.createOrReplaceTempView("matchedInvoice_df")
  val openInvoice = sqlcontext.sql("SELECT * FROM invoice_df WHERE Invoice_No NOT IN (SELECT Invoice_No FROM matchedInvoice_df)")
  val openTransaction = sqlcontext.sql("SELECT * FROM payment_df WHERE Payment_No NOT IN (SELECT Payment_No FROM matchedInvoice_df)")

  //case where amount doesnt match
  val finalResult = InvoiceRecognition.finalResult.union(DirectMatching.matchedInvoiceFinal)
  val result = InvoiceRecognition.result
  result.createOrReplaceTempView("result_df")
  finalResult.createOrReplaceTempView("finalResult_df")
  val probableMatch = sqlcontext.sql("SELECT Payment_No,Amount,Invoice_No,Total,Description FROM result_df WHERE Payment_No NOT IN (SELECT Payment_No FROM finalResult_df)").union(DirectMatching.probDirectMatch)
  val probMatch = probableMatch.toDF().collect().map(makeJson(_))

}
