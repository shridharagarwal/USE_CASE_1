package com.squareone.bankiq
import org.apache.spark.sql.Row

object SuspenseTransaction {
    DirectMatching.payment.createOrReplaceTempView("Payment_df")
    ProbableMatch.probableMatch.createOrReplaceTempView("probableMatch_df")
    val sqlContext = DirectMatching.sqlContext
    val matchedInvoice = MultipleInvoice.multipleMatchedInvoice
    val probablePayment = ProbableMatch.probableMatch
    matchedInvoice.createOrReplaceTempView("matchedInvoice_df")
    probablePayment.createOrReplaceTempView("probablePayment_df")
    val suspenseTransaction = sqlContext.sql("SELECT Payment_No,Account_No,Name,Amount,Date,Description FROM Payment_df WHERE Payment_No NOT IN " +
      "(Select Payment_No FROM matchedInvoice_df UNION Select Payment_No FROM probablePayment_df)")
  println("Suspense Transaction")
  suspenseTransaction.show()
    def SuspenseTran(row: Row) ={
      Transaction(row(0).toString,row(1).toString,row(2).toString,row(3).toString,row(4).toString,row(5).toString)
    }
    val susTran = suspenseTransaction.toDF().collect().map(SuspenseTran(_))
}
