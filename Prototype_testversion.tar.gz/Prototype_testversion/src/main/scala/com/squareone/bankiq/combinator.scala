package com.squareone.bankiq

object combinator {
    def combinations(size: Int) = {
      val l = (1 to size).toList
      val r = l.toSet[Int].subsets.map(_.toList).toList
      r
    }
}
