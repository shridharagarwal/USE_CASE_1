package com.squareone.bankiq
import java.text.SimpleDateFormat

import io.lamma.Date
import com.squareone.bankiq.InvoiceRecognition.makeJson
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions
import org.joda.time.LocalDate
import org.joda.time.format.{DateTimeFormat, DateTimeFormatter}
import org.apache.spark.sql.Column
import scala.collection.mutable.ListBuffer

object Liquidity extends App{

  import org.apache.spark

  val sqlContext = DirectMatching.sqlContext

  val invoice = DirectMatching.invoice
  val payment = DirectMatching.payment
  val matchedInvoice = MultipleInvoice.multipleMatchedInvoice

  invoice.createOrReplaceTempView("invoice_df")
  payment.createOrReplaceTempView("payment_df")
  matchedInvoice.createOrReplaceTempView("matchedInvoice_df")
  val openInvoice = sqlContext.sql("SELECT Invoice_No,Total,Customer_Name,Due_Date  FROM invoice_df WHERE Invoice_No NOT IN (SELECT Invoice_No FROM matchedInvoice_df)")
  val openTransaction = sqlContext.sql("SELECT * FROM payment_df WHERE Payment_No NOT IN (SELECT Payment_No FROM matchedInvoice_df)")
  val payable = sqlContext.read.option("header","true").csv("DataFile/test-AP.csv")
  payable.createOrReplaceTempView("payable_df")

 val sf = new SimpleDateFormat("yyyy/MM/dd")
  import sqlContext.implicits._
  val startDate = Date.today()
  val endDate = startDate + 90
  var dataRange = new ListBuffer[String]
  //dataRange += startDate
  val r = (startDate to endDate).foldLeft(dataRange){(acc,x) => acc += x.toString}
  val k = r.toList
  def dateModifier(input: String): String = {
    input.stripPrefix("Date(").stripSuffix(")").replace(",","/")
  }
  val i = k.map(x => dateModifier(x))
  val dateResult = i.toDF("dateRange")
  dateResult.show()
  dateResult.createOrReplaceTempView("dateResult_df")
  openInvoice.createOrReplaceTempView("openInvoice_df")
  println("openInvoice")
  openInvoice.show()

  sqlContext.udf.register("formatter", (input: String) => sf.format(input))

  val a = sqlContext.sql("SELECT dateRange,Sum(Total) AS Total,Sum(Amount) AS Amount FROM dateResult_df AS dr " +
    "LEFT JOIN openInvoice_df AS oi ON dr.dateRange = oi.Due_Date LEFT JOIN payable_df AS pay ON dr.dateRange = pay.Date GROUP BY dateRange")
  a.show()
  a.createOrReplaceTempView("a_df")
  val b = sqlContext.sql("""SELECT TO_DATE(CAST(UNIX_TIMESTAMP(dateRange, 'yyyy/MM/dd') AS TIMESTAMP)) AS Date,Total,Amount FROM a_df ORDER BY date ASC""")
  //b.createOrReplaceTempView("b_df")
  //val c = sqlContext.sql("SELECT Date,Total - Amount FROM b_df").show

  val df = b.selectExpr("Date","cast (Total as Int) AR", "cast (Amount as Int) AP")
  df.show()

  val amountRemaining = sqlContext.sql("SELECT Sum(Total) AS Total FROM invoice_df").head().getAs[Double]("Total") -
    sqlContext.sql("SELECT Sum(Amount) AS Amount FROM payment_df").head().getAs[Double]("Amount")
  val percentRecovery = 0.95
  var balance = 100000 + percentRecovery *amountRemaining

  def cash(row: Row) = {
    val p = (if(row(1) != null) {row(1)}else{0}).toString.toDouble - (if(row(1) != null) {row(1)}else{0}).toString.toDouble
    balance = balance + p
    (row(0).toString, balance)
  }

  def make(row:Row) = {
    Cash(row(0).toString,row(1).toString.toDouble)
  }
  println(df.getClass)
  df.map(cash(_)).toDF().show()//.orderBy("Day").toDF()//.collect().map(make(_))
}
