package com.squareone.bankiq

import io.lamma.Date
import org.apache.spark.sql.Row

import scala.collection.mutable.ListBuffer

object liquidityPrediction extends App{
  val sqlContext = DirectMatching.sqlContext
  val customerWiseDso = sqlContext.read.option("header","true").csv("DataFile/customerWiseDso.csv")
  customerWiseDso.createOrReplaceTempView("customerWiseDso_df")

  val invoice = DirectMatching.invoice
  val payment = DirectMatching.payment
  val matchedInvoice = MultipleInvoice.multipleMatchedInvoice

  invoice.createOrReplaceTempView("invoice_df")
  payment.createOrReplaceTempView("payment_df")
  matchedInvoice.createOrReplaceTempView("matchedInvoice_df")
  val openInvoice = sqlContext.sql("SELECT Customer_Number,Invoice_No,Total,Customer_Name,Due_Date  FROM invoice_df WHERE Invoice_No NOT IN (SELECT Invoice_No FROM matchedInvoice_df)")
  val openTransaction = sqlContext.sql("SELECT * FROM payment_df WHERE Payment_No NOT IN (SELECT Payment_No FROM matchedInvoice_df)")
  val payable = sqlContext.read.option("header","true").csv("/home/shridhar/Desktop/USE CASE 1/Prototype/test-AP.csv")
  payable.createOrReplaceTempView("payable_df")
  openInvoice.createOrReplaceTempView("openInvoice_df")
  import sqlContext.implicits._

  val openInvoiceWithDSO = sqlContext.sql("SELECT Invoice_No,Total,date_add(TO_DATE(CAST(UNIX_TIMESTAMP(Due_Date, 'yyyy/MM/dd') AS TIMESTAMP)), DSO) AS PredictedDate FROM openInvoice_df INNER JOIN customerWiseDso_df ON Customer_Number = Customer_Code")
  openInvoiceWithDSO.show()
  openInvoiceWithDSO.createOrReplaceTempView("openInvoiceWithDso_df")
  val startDate = Date.today()
  val endDate = startDate + 90
  var dataRange = new ListBuffer[String]
  //dataRange += startDate
  val r = (startDate to endDate).foldLeft(dataRange){(acc,x) => acc += x.toString}
  val k = r.toList
  def dateModifier(input: String): String = {
    input.stripPrefix("Date(").stripSuffix(")").replace(",","/")
  }
  val i = k.map(x => dateModifier(x))
  val dateResult = i.toDF("dateRange")
  dateResult.createOrReplaceTempView("dateResult_df")

  val a = sqlContext.sql("SELECT dateRange,Sum(Total) AS Total,Sum(Amount) AS Amount FROM dateResult_df AS dr " +
    "LEFT JOIN openInvoiceWithDso_df AS oi ON dr.dateRange = oi.PredictedDate LEFT JOIN payable_df AS pay ON dr.dateRange = pay.Date GROUP BY dateRange")
  a.createOrReplaceTempView("a_df")
  val b = sqlContext.sql("""SELECT TO_DATE(CAST(UNIX_TIMESTAMP(dateRange, 'yyyy/MM/dd') AS TIMESTAMP)) AS Date,Total,Amount FROM a_df ORDER BY date ASC""")
  b.show()

  val df = b.selectExpr("Date","cast (Total as Int) AR", "cast (Amount as Int) AP")
  df.show()

  val amountRemaining = sqlContext.sql("SELECT Sum(Total) AS Total FROM inv   oice_df").head().getAs[Double]("Total") -
    sqlContext.sql("SELECT Sum(Amount) AS Amount FROM payment_df").head().getAs[Double]("Amount")
  val percentRecovery = 0.95
  var balance = 100000 + percentRecovery *amountRemaining

  def cash(row: Row) = {
    val p = (if(row(1) != null) {row(1)}else{0}).toString.toDouble - (if(row(1) != null) {row(1)}else{0}).toString.toDouble
    balance = balance + p
    (row(0).toString, balance)
  }

  def make(row:Row) = {
    Cash(row(0).toString,row(1).toString.toDouble)
  }
  println(df.getClass)
  df.map(cash(_)).toDF().show()
}
