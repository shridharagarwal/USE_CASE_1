package com.squareone.bankiq

case class MatchedInvoice(Payment_No:String,Amount:String,Invoice_No:String,Total:String,Description:String)
case class MatchedInvoice2(Customer_Code: String,Customer_Name: String,Account_No: String,Payment_No: String, Amount:String,Invoice_No:String,Total:String,Description:String)
case class CustomerDSO(CustomerID:String,DSO:Double)
case class DisputedDSO(DisputedID:String,DSO:Double)
case class Transaction(PaymentNo: String, AccountNo: String, AccountName: String, Amount: String,Date: String,Description: String)
case class Cash(Day:String,Balance:Double)
case class DelayedIndicator(customerID: String, InvoiceNumber: String, InvoiceDate: String,DueDate: String,InvoiceAmount: String,Disputed: String,Status: String)