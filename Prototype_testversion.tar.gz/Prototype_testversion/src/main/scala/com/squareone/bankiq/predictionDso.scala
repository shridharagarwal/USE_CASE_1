package com.squareone.bankiq

import com.squareone.bankiq.InvoiceRecognition.sqlContext
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.classification.LogisticRegression
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.sql.{DataFrame, Row, SQLContext}


object predictionDso{

      val sqlContext = DirectMatching.sqlContext

      import sqlContext.implicits._
      def load(path: String, sqlContext: SQLContext, featuresArr: String*): DataFrame = {
        var data = sqlContext.read.format("com.databricks.spark.csv")
          .option("header", "true")
          .option("inferSchema", "true")
          .load(path)
          .toDF(featuresArr: _*)
        return data
      }


      var train_data = sqlContext.read
        .format("com.databricks.spark.csv")
        .option("header", "true").option("inferSchema", "true")
        .load("DataFile/ar_train.csv") //.toDF(featuresArr: _*)

      var test_data = sqlContext.read.format("com.databricks.spark.csv")
        .option("header", "true")
        .option("inferSchema", "true")
        .load("DataFile/ar_test.csv")//.toDF(featuresArr: _*)

      var for_predict = sqlContext.read.format("com.databricks.spark.csv")
        .option("header", "true")
        .option("inferSchema", "true")
        .load("DataFile/For_predict.csv")
      for_predict.show()

      val toDouble = sqlContext.udf.register("toDouble", ((n: Int) => {
        n.toDouble
      }))
      train_data = train_data.withColumn("customer_factor", toDouble(train_data("customer_factor")))
      train_data = train_data.withColumn("Disputed", toDouble(train_data("Disputed")))
      train_data = train_data.withColumn("Delayed", toDouble(train_data("Delayed")))
      //train_data.printSchema()

      test_data = train_data.withColumn("customer_factor", toDouble(train_data("customer_factor")))
      test_data = train_data.withColumn("Disputed", toDouble(train_data("Disputed")))
      test_data = train_data.withColumn("Delayed", toDouble(train_data("Delayed")))

      for_predict = for_predict.withColumn("customer_factor", toDouble(for_predict("customer_factor")))
      for_predict = for_predict.withColumn("Disputed", toDouble(for_predict("Disputed")))
      for_predict.show()
      //val assembler = new VectorAssembler().setInputCols(Array("customer_factor", "Disputed")).setOutputCol("features_temp")
      val assembler = new VectorAssembler().setInputCols(Array("customer_factor", "Disputed")).setOutputCol("features")
      val lr = new LogisticRegression().setMaxIter(10)

      lr.setLabelCol("Delayed")

      val pipeline = new Pipeline().setStages(Array(assembler, lr))
      val model = pipeline.fit(train_data)
      var result = model.transform(test_data)
      result.show()
      result = result.select("prediction", "Delayed")
      val predictionAndLabels = result.map { row =>
        (row.get(0).asInstanceOf[Double], row.get(1).asInstanceOf[Double])
      }.rdd

   /*   val metrics = new MulticlassMetrics(predictionAndLabels)
      val precision = metrics.precision
      println("Precision = " + precision)

      val metrics_roc = new BinaryClassificationMetrics(predictionAndLabels)
      println("Area under ROC = " + metrics_roc.areaUnderROC())*/


      val getZero = sqlContext.udf.register("toDouble", ((n: Int) => {
        0.0
      }))
      test_data = test_data.withColumn("Delayed", toDouble(test_data("customer_factor")))
      result = model.transform(test_data)
      result = result.select("Customer_factor", "prediction")
      /////////////////////////////////////////////////////////////////////////////
      for_predict = for_predict.withColumn("Survived", toDouble(for_predict("customer_factor")))

      result = model.transform(for_predict)
      val selectedResult = result.select("customer_factor","prediction")
      selectedResult.createOrReplaceTempView("selectedResult_df")
      val overallSet = sqlContext.read.option("header","true").csv("DataFile/Accounts-Receivable.csv")
      overallSet.createOrReplaceTempView("overallSet_df")

      sqlContext.udf.register("DelayedIndicator",(input: Int) => if (input == 1) "Delayed" else "On Time")
    def delayedInd(row : Row) ={
      DelayedIndicator(row(0).toString,row(1).toString,row(2).toString,row(3).toString,row(4).toString,row(5).toString,row(6).toString)
    }
      val finalResult = sqlContext.sql("SELECT customerID, InvoiceNumber, InvoiceDate,DueDate,InvoiceAmount,Disputed,DelayedIndicator(prediction) " +
        "as Status FROM overallSet_df INNER JOIN selectedResult_df ON customer_factor = customerID").toDF().collect().map(delayedInd(_))
}
