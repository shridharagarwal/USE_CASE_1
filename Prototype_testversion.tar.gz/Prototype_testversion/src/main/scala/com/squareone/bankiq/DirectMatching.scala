package com.squareone.bankiq

import org.apache.spark.sql.{Row, SparkSession}

object DirectMatching {
    val sqlContext = SparkSession.builder().appName("proto").master("local").getOrCreate()
    val invoice = sqlContext.read.option("header","true").csv("DataFile/test-invoice.csv")
    val payment = sqlContext.read.option("header","true").csv("DataFile/test-payment.csv")
    val customer = sqlContext.read.option("header","true").csv("DataFile/test-customer.csv")

    invoice.createOrReplaceTempView("invoice_df")
    payment.createOrReplaceTempView("payment_df")
    customer.createOrReplaceTempView("customer_df")

    val matchedInvoice = sqlContext.sql("""SELECT Payment_No,Amount,Invoice_No,Total,Description FROM invoice_df """ +
      """INNER JOIN customer_df ON Customer_Number = Code""" +
      """ INNER JOIN payment_df ON Account_Number = Account_no and Total = Amount""")
    matchedInvoice.show()
  matchedInvoice.createOrReplaceTempView("matchedInvoice_df")
  val count = sqlContext.sql("SELECT count(Invoice_No) as counter,Payment_No FROM matchedInvoice_df GROUP BY Payment_No")
  count.createOrReplaceTempView("count_df")
  println("count")
  count.show
  val probDirectMatch = sqlContext.sql("SELECT * FROM matchedInvoice_df WHERE Payment_No IN (SELECT Payment_No FROM count_df WHERE counter > 1)")
  val matchedInvoiceFinal = sqlContext.sql("SELECT * FROM matchedInvoice_df WHERE Payment_No IN (SELECT Payment_No FROM count_df WHERE counter = 1)")
  println("matchedInvoiceFinal")
  matchedInvoiceFinal.show
  def makeJson(row: Row) = {
    MatchedInvoice(row(0).toString,row(1).toString,row(2).toString,row(3).toString,row(4).toString)
  }
}
