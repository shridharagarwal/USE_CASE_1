package com.squareone.bankiq

import org.apache.spark.sql.{Row, SparkSession}

object InvoiceRecognition {
    val sqlContext = DirectMatching.sqlContext

    DirectMatching.invoice.createOrReplaceTempView("invoice_df")
    DirectMatching.payment.createOrReplaceTempView("payment_df")
    DirectMatching.customer.createOrReplaceTempView("customer_df")
    DirectMatching.matchedInvoice.createOrReplaceTempView(("matchedInvoice_df"))

    //Payment that are still open
    val openPayment = sqlContext.sql("SELECT Payment_No,Amount,Date,Account_No,Description FROM payment_df " +
      "WHERE Payment_No NOT IN (SELECT Payment_No FROM matchedInvoice_df)")
    openPayment.createOrReplaceTempView("openPayment_df")
    println("openPayment")
    openPayment.show()

    // Invoices that are still open
    val openInvoice = sqlContext.sql("SELECT Invoice_No,Total,Due_Date, Customer_Number FROM invoice_df" +
      " WHERE Invoice_No NOT IN (SELECT Invoice_No FROM matchedInvoice_df)")
    println("openInvoice")
    openInvoice.show()
    openInvoice.createOrReplaceTempView(("openInvoice_df"))

    // Matching Invoices with payments based upon customer account
    val relatedInvoice = sqlContext.sql("SELECT Invoice_No,Total,Due_Date,Payment_No,Amount,Date,Description FROM openInvoice_df " +
      "INNER JOIN customer_df ON Customer_Number = Code " +
      "INNER JOIN openPayment_df ON Account_Number = Account_No")
    relatedInvoice.show()
    relatedInvoice.createOrReplaceTempView("relatedInvoice_df")

    //Create UDF for string format
    sqlContext.udf.register("CreateExp",(input: String) => "%" + input + "%")

    // Resultset containing matched invoice with those given in description
    val result = sqlContext.sql("""SELECT Payment_No,Amount,Invoice_No,Total,Description FROM relatedInvoice_df
                                  |Where Description LIKE CreateExp(Invoice_No)""".stripMargin)
    result.show()
    result.createOrReplaceTempView("result_df")
    val total = sqlContext.sql("SELECT Sum(Total) as Total, Max(Amount) as Amount, Payment_No FROM result_df GROUP BY Payment_No")
    total.show
    total.createOrReplaceTempView("total_df")
    val payment_no_accepted = sqlContext.sql("SELECT Payment_No FROM total_df WHERE Total = Amount")
    payment_no_accepted.createOrReplaceTempView("paymentAccepted_df")

    val finalResult = sqlContext.sql("SELECT Payment_No,Amount,Invoice_No,Total,Description FROM result_df " +
      "WHERE Payment_No IN (SELECT Payment_No FROM paymentAccepted_df)")
    finalResult.show()

    val matchedWithInvoice = DirectMatching.matchedInvoiceFinal.union(finalResult)
    def makeJson(row: Row) = {
      MatchedInvoice(row(0).toString,row(1).toString,row(2).toString,row(3).toString,row(4).toString)
    }
}
