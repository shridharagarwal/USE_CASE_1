package com.squareone.bankiq

import com.squareone.bankiq.InvoiceRecognition.makeJson
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

object MultipleInvoice {
  val sqlContext = DirectMatching.sqlContext

  val invoice = DirectMatching.invoice
  invoice.createOrReplaceTempView("Invoice_df")
  val probMatch = DirectMatching.probDirectMatch
  probMatch.createOrReplaceTempView("probMatch_df")
  InvoiceRecognition.matchedWithInvoice.createOrReplaceTempView("matchedInvoice_df")
  val openInvoice = sqlContext.sql("SELECT * FROM Invoice_df WHERE Invoice_No NOT IN(SELECT Invoice_No From matchedInvoice_df) AND Invoice_No NOT IN (SELECT Invoice_No FROM probMatch_df)")
  openInvoice.show()
  import sqlContext.implicits._

  val invoice_selected= openInvoice.select("Invoice_No","Total")

  def dfZipWithIndex(
                      df: DataFrame,
                      offset: Int = 1,
                      colName: String = "id",
                      inFront: Boolean = true
                    ) : DataFrame = {
    df.sqlContext.createDataFrame(
      df.rdd.zipWithIndex.map(ln =>
        Row.fromSeq(
          (if (inFront) Seq(ln._2 + offset) else Seq())
            ++ ln._1.toSeq ++
            (if (inFront) Seq() else Seq(ln._2 + offset))
        )
      ),
      StructType(
        (if (inFront) Array(StructField(colName,LongType,false)) else Array[StructField]())
          ++ df.schema.fields ++
          (if (inFront) Array[StructField]() else Array(StructField(colName,LongType,false)))
      )
    )
  }
  val numOfInvoice = invoice_selected.count().toInt
  val com = combinator.combinations(numOfInvoice) // generate all possible combinations
  val res = dfZipWithIndex(invoice_selected)
  res.show()
  val tranAmountDF = sqlContext.sql("SELECT Payment_No,Amount FROM Payment_df Where Payment_No NOT IN (SELECT Payment_No FROM matchedInvoice_df)")
  val tranAmount = tranAmountDF.select("Payment_No", "Amount").rdd.map(x => (x.getAs[String](0), x.getAs[String](1).toInt)).collect()
  var invCombination: List[List[Int]] = List(Nil)
  println("multipleInvoice1")

  var payCombination: List[List[String]] = List(Nil)
  com.foreach(x => {val amt = x.foldLeft(0) { case (acc, y) => acc + res.filter($"id".like(y.toString)).head().getAs[String]("Total").toInt
      };
    if(tranAmount.find(x => x._2 == amt) != None)
      {invCombination = x::invCombination;
        tranAmount.foreach(x=> if(x._2 == amt)payCombination = List(x._1)::payCombination );
      }
    }
  )
  println("matchedInvoice2")
  val finishedList = invCombination.zip(payCombination)
  var acc : List[(String,String)] = List(("",""))
  val finalList: List[(String, String)] = finishedList.foldLeft(acc){ (acc, x) => {
    var second = x._2;
    (x._1).foldLeft(acc){(acc,y) =>
      ((res.filter($"id".like(y.toString)).head().getAs[String]("Invoice_No"),second.head.toString())::acc)
      }
    }
  }

  val finalDF = finalList.toDF("Invoice_No","Payment_No")
  println(finalList.getClass)
  finalDF.createOrReplaceTempView("finalDF")

  def matchforJson(row: Row) = {
    MatchedInvoice2(row(0).toString,row(1).toString,row(2).toString,row(3).toString,row(4).toString,row(5).toString,row(6).toString,row(7).toString)
  }

  val multipleMatchedInvoice = sqlContext.sql("SELECT pay.Payment_No,pay.Amount,inv.Invoice_No,inv.Total, pay.Description FROM Invoice_df inv INNER JOIN finalDF fin " +
    "ON inv.Invoice_No = fin.Invoice_No INNER JOIN Payment_df pay ON pay.Payment_No = fin.Payment_No ").union(InvoiceRecognition.matchedWithInvoice)

 /* val matchedMultiple = sqlContext.sql("SELECT inv.Customer_Number,inv.Customer_Name,pay.Account_No,pay.Payment_No,pay.Amount,inv.Invoice_No,inv.Total, pay.Description FROM Invoice_df inv INNER JOIN finalDF fin " +
    "ON inv.Invoice_No = fin.Invoice_No INNER JOIN Payment_df pay ON pay.Payment_No = fin.Payment_No ").union(InvoiceRecognition.matchedWithInvoice).toDF().collect().map(matchforJson(_))
  //matchedMultiple.show()*/
  val matchedMultiple = sqlContext.sql("SELECT pay.Payment_No,pay.Amount,inv.Invoice_No,inv.Total, pay.Description FROM Invoice_df inv INNER JOIN finalDF fin " +
    "ON inv.Invoice_No = fin.Invoice_No INNER JOIN Payment_df pay ON pay.Payment_No = fin.Payment_No ").union(InvoiceRecognition.matchedWithInvoice).toDF().collect().map(makeJson(_))
  //matchedMultiple.show()
  println("multipleInvoice-Complete")
}
