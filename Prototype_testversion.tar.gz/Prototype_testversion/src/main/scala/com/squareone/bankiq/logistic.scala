package com.squareone.bankiq
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.mllib.classification.LogisticRegressionWithLBFGS
import org.apache.spark.mllib.evaluation.MulticlassMetrics
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.linalg.{Vector, Vectors}

object logistic extends App {
      val conf = new SparkConf().setAppName("logistic").setMaster("local[*]")
      val sc = new SparkContext(conf)
      val data = sc.textFile("DataFile/ar_before_part.csv")
      val splits = data.randomSplit(Array(0.75, 0.25), seed = 11L)
      val trainingData = splits(0)
      val testData = splits(1)
      println(trainingData.count())
      println(testData.count())

      //previous case
       val train = trainingData.map{line =>
         val parts = line.split(",")
         LabeledPoint(parts(2).toDouble,Vectors.dense(parts(0).toDouble,parts(1).toDouble))
       }
       val test = testData.map{line =>
         val parts = line.split(",")
         LabeledPoint(parts(2).toDouble,Vectors.dense(parts(0).toDouble,parts(1).toDouble))
       }

      val model = new LogisticRegressionWithLBFGS()
        .setNumClasses(2)
        .run(train)


      println("now here")
      val predictionModel = test.map{ case LabeledPoint(label, features) =>
        val prediction = model.predict(features)
        println(prediction, label)
        //println(label)
        (prediction,label)
      }
      println(predictionModel.count())
      //predictionModel.map(line => println("prediction:" + line._1 + ", label:" + line._2))
      print("test")
      val metrics = new MulticlassMetrics(predictionModel)
      val precision = metrics.precision
      println("Precision = " + precision)

      /*model.save(sc, "shridhar")
     val sameModel = LogisticRegressionModel.load(sc, "myModelPath")*/
}
